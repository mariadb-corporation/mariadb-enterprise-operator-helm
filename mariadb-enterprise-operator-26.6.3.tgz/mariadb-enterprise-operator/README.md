# mariadb-enterprise-operator

![Version: 26.6.3](https://img.shields.io/badge/Version-26.6.3-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square) ![AppVersion: 26.6.3](https://img.shields.io/badge/AppVersion-26.6.3-informational?style=flat-square)

Run and operate MariaDB Enterprise in Kubernetes

**Homepage:** <https://github.com/mariadb-corporation/mariadb-enterprise-operator-helm>

## Maintainers

| Name | Email | Url |
| ---- | ------ | --- |
| MariaDB Corporation | <operator@mariadb.com> |  |
| Support | <support@mariadb.com> |  |
| Sales EMEA | <sales-EMEA@mariadb.com> |  |
| Sales APAC | <sales-APAC@mariadb.com> |  |
| Sales Americas | <sales-nam@mariadb.com> |  |

## Requirements

Kubernetes: `>=1.26.0-0`

| Repository | Name | Version |
|------------|------|---------|
| file://../mariadb-enterprise-operator-crds | mariadb-enterprise-operator-crds | 26.6.3 |

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| affinity | object | `{}` | Affinity to add to controller Pod |
| certController.affinity | object | `{}` | Affinity to add to cert-controller container |
| certController.caLifetime | string | `"26280h"` | CA certificate lifetime. It must be greater than certLifetime. |
| certController.certLifetime | string | `"2160h"` | Certificate lifetime. |
| certController.enabled | bool | `true` | Specifies whether the cert-controller should be created. |
| certController.extraArgs | list | `[]` | Extra arguments to be passed to the cert-controller entrypoint |
| certController.extraVolumeMounts | list | `[]` | Extra volumes to mount to cert-controller container |
| certController.extraVolumes | list | `[]` | Extra volumes to pass to cert-controller Pod |
| certController.ha.enabled | bool | `false` | Enable high availability |
| certController.ha.replicas | int | `3` | Number of replicas |
| certController.image.pullPolicy | string | `"IfNotPresent"` |  |
| certController.image.repository | string | `"docker.mariadb.com/mariadb-enterprise-operator"` |  |
| certController.image.tag | string | `""` | Image tag to use. By default the chart appVersion is used |
| certController.imagePullSecrets | list | `[]` |  |
| certController.nodeSelector | object | `{}` | Node selectors to add to cert-controller container |
| certController.pdb.enabled | bool | `false` | Enable PodDisruptionBudget for the cert-controller. |
| certController.pdb.maxUnavailable | int | `1` | Maximum number of unavailable Pods. You may also give a percentage, like `50%` |
| certController.podAnnotations | object | `{}` | Annotations to add to cert-controller Pod |
| certController.podSecurityContext | object | `{}` | Security context to add to cert-controller Pod |
| certController.priorityClassName | string | `""` | priorityClassName to add to cert-controller container |
| certController.privateKeyAlgorithm | string | `"ECDSA"` | Private key algorithm to be used for the CA and leaf certificate private keys. One of: ECDSA or RSA. |
| certController.privateKeySize | int | `256` | Private key size to be used for the CA and leaf certificate private keys. Supported values: ECDSA(256, 384, 521), RSA(2048, 3072, 4096) |
| certController.renewBeforePercentage | int | `33` | How long before the certificate expiration should the renewal process be triggered. For example, if a certificate is valid for 60 minutes, and renewBeforePercentage=25, cert-controller will begin to attempt to renew the certificate 45 minutes after it was issued (i.e. when there are 15 minutes (25%) remaining until the certificate is no longer valid). |
| certController.requeueDuration | string | `"5m"` | Requeue duration to ensure that certificate gets renewed. |
| certController.resources | object | `{}` | Resources to add to cert-controller container |
| certController.revisionHistoryLimit | int | `10` | Specifies the amount of historic ReplicaSets k8s should keep (see https://kubernetes.io/docs/concepts/workloads/controllers/deployment/#clean-up-policy) |
| certController.securityContext | object | `{}` | Security context to add to cert-controller Pod |
| certController.serviceAccount.annotations | object | `{}` | Annotations to add to the service account |
| certController.serviceAccount.automount | bool | `true` | Automounts the service account token in all containers of the Pod |
| certController.serviceAccount.enabled | bool | `true` | Specifies whether a service account should be created |
| certController.serviceAccount.extraLabels | object | `{}` | Extra Labels to add to the service account |
| certController.serviceAccount.name | string | `""` | The name of the service account to use. If not set and enabled is true, a name is generated using the fullname template |
| certController.serviceMonitor.additionalLabels | object | `{}` | Labels to be added to the cert-controller ServiceMonitor |
| certController.serviceMonitor.enabled | bool | `true` | Enable cert-controller ServiceMonitor. Metrics must be enabled |
| certController.serviceMonitor.interval | string | `"30s"` | Interval to scrape metrics |
| certController.serviceMonitor.metricRelabelings | list | `[]` |  |
| certController.serviceMonitor.relabelings | list | `[]` |  |
| certController.serviceMonitor.scrapeTimeout | string | `"25s"` | Timeout if metrics can't be retrieved in given time interval |
| certController.strategy | object | `{}` | Set deployment strategy |
| certController.tolerations | list | `[]` | Tolerations to add to cert-controller container |
| certController.topologySpreadConstraints | list | `[]` | topologySpreadConstraints to add to cert-controller container |
| clusterName | string | `"cluster.local"` | Cluster DNS name |
| config.exporterImage | object | `{"repository":"mariadb/mariadb-prometheus-exporter-ubi","tag":"1.2.0"}` | Default MariaDB exporter image |
| config.exporterMaxscaleImage | object | `{"repository":"mariadb/maxscale-prometheus-exporter-ubi","tag":"1.2.0"}` | Default MaxScale exporter image |
| config.galeraLibPath | string | `"/usr/lib64/galera/libgalera_enterprise_smm.so"` | Galera Enterprise library path to be used with Galera |
| config.mariadbDefaultVersion | string | `"11.8"` | Default MariaDB Enterprise version to be used when unable to infer it via image tag |
| config.mariadbImage | object | `{"repository":"docker.mariadb.com/enterprise-server","tag":"11.8.8-5"}` | Default MariaDB Enterprise image |
| config.mariadbImageName | string | `"docker.mariadb.com/enterprise-server"` | Default MariaDB Enterprise image name |
| config.maxscaleImage | object | `{"repository":"docker.mariadb.com/maxscale","tag":"25.10.3"}` | Default MaxScale Enterprise image |
| crds | object | `{"enabled":false}` | CRDs |
| crds.enabled | bool | `false` | Whether the helm chart should create and update the CRDs. It is false by default, which implies that the CRDs must be managed independently with the mariadb-enterprise-operator-crds helm chart. **WARNING** This should only be set to true during the initial deployment. If this chart manages the CRDs and is later uninstalled, all MariaDB instances will be DELETED. |
| currentNamespaceOnly | bool | `false` | Whether the operator should watch CRDs only in its own namespace or not. |
| extraArgs | list | `[]` | Extra arguments to be passed to the controller entrypoint |
| extraEnv | list | `[]` | Extra environment variables to be passed to the controller |
| extraEnvFrom | list | `[]` | Extra environment variables from preexiting ConfigMap / Secret objects used by the controller using envFrom |
| extraVolumeMounts | list | `[]` | Extra volumes to mount to the container. |
| extraVolumes | list | `[]` | Extra volumes to pass to pod. |
| fullnameOverride | string | `""` |  |
| ha.enabled | bool | `false` | Enable high availability of the controller. If you enable it we recommend to set `affinity` and `pdb` |
| ha.replicas | int | `3` | Number of replicas |
| image.pullPolicy | string | `"IfNotPresent"` |  |
| image.repository | string | `"docker.mariadb.com/mariadb-enterprise-operator"` |  |
| image.tag | string | `""` | Image tag to use. By default the chart appVersion is used |
| imagePullSecrets | list | `[]` |  |
| logLevel | string | `"INFO"` | Controller log level |
| metrics.enabled | bool | `false` | Enable operator internal metrics. Prometheus must be installed in the cluster |
| metrics.serviceMonitor.additionalLabels | object | `{}` | Labels to be added to the controller ServiceMonitor |
| metrics.serviceMonitor.enabled | bool | `true` | Enable controller ServiceMonitor |
| metrics.serviceMonitor.interval | string | `"30s"` | Interval to scrape metrics |
| metrics.serviceMonitor.metricRelabelings | list | `[]` |  |
| metrics.serviceMonitor.relabelings | list | `[]` |  |
| metrics.serviceMonitor.scrapeTimeout | string | `"25s"` | Timeout if metrics can't be retrieved in given time interval |
| nameOverride | string | `""` |  |
| nodeSelector | object | `{}` | Node selectors to add to controller Pod |
| pdb.enabled | bool | `false` | Enable PodDisruptionBudget for the controller. |
| pdb.maxUnavailable | int | `1` | Maximum number of unavailable Pods. You may also give a percentage, like `50%` |
| podAnnotations | object | `{}` | Annotations to add to controller Pod |
| podSecurityContext | object | `{}` | Security context to add to controller Pod |
| pprof.enabled | bool | `false` | Enable the pprof HTTP server. |
| pprof.port | int | `6060` | The port where the pprof HTTP server listens. |
| priorityClassName | string | `""` | priorityClassName to add to controller Pod |
| rbac.aggregation.enabled | bool | `true` | Specifies whether the cluster roles aggregate to view and edit predefinied roles |
| rbac.enabled | bool | `true` | Specifies whether RBAC resources should be created |
| resources | object | `{}` | Resources to add to controller container |
| revisionHistoryLimit | int | `10` | Specifies the amount of historic ReplicaSets k8s should keep (see https://kubernetes.io/docs/concepts/workloads/controllers/deployment/#clean-up-policy) |
| securityContext | object | `{}` | Security context to add to controller container |
| serviceAccount.annotations | object | `{}` | Annotations to add to the service account |
| serviceAccount.automount | bool | `true` | Automounts the service account token in all containers of the Pod |
| serviceAccount.enabled | bool | `true` | Specifies whether a service account should be created |
| serviceAccount.extraLabels | object | `{}` | Extra Labels to add to the service account |
| serviceAccount.name | string | `""` | The name of the service account to use. If not set and enabled is true, a name is generated using the fullname template |
| strategy | object | `{}` | Set deployment strategy |
| tolerations | list | `[]` | Tolerations to add to controller Pod |
| topologySpreadConstraints | list | `[]` | topologySpreadConstraints to add to controller Pod |
| webhook.affinity | object | `{}` | Affinity to add to webhook Pod |
| webhook.annotations | object | `{}` | Annotations for webhook configurations. |
| webhook.cert.ca.key | string | `""` | File under 'ca.path' that contains the full CA trust chain. |
| webhook.cert.ca.path | string | `""` | Path that contains the full CA trust chain. |
| webhook.cert.certManager.duration | string | `""` | Duration to be used in the Certificate resource, |
| webhook.cert.certManager.enabled | bool | `false` | Whether to use cert-manager to issue and rotate the certificate. If set to false, mariadb-enterprise-operator's cert-controller will be used instead. |
| webhook.cert.certManager.issuerRef | object | `{}` | Issuer reference to be used in the Certificate resource. If not provided, a self-signed issuer will be used. |
| webhook.cert.certManager.privateKeyAlgorithm | string | `"ECDSA"` | Private key algorithm to be used for the CA and leaf certificate private keys. One of: ECDSA or RSA. |
| webhook.cert.certManager.privateKeySize | int | `256` | Private key size to be used for the CA and leaf certificate private keys. Supported values: ECDSA(256, 384, 521), RSA(2048, 3072, 4096) |
| webhook.cert.certManager.renewBefore | string | `""` | Renew before duration to be used in the Certificate resource. |
| webhook.cert.certManager.revisionHistoryLimit | int | `3` | The maximum number of CertificateRequest revisions that are maintained in the Certificate’s history. |
| webhook.cert.path | string | `"/tmp/k8s-webhook-server/serving-certs"` | Path where the certificate will be mounted. 'tls.crt' and 'tls.key' certificates files should be under this path. |
| webhook.cert.secretAnnotations | object | `{}` | Annotatioms to be added to webhook TLS secret. |
| webhook.cert.secretLabels | object | `{}` | Labels to be added to webhook TLS secret. |
| webhook.enabled | bool | `true` | Specifies whether the webhook should be created. |
| webhook.extraArgs | list | `[]` | Extra arguments to be passed to the webhook entrypoint |
| webhook.extraVolumeMounts | list | `[]` | Extra volumes to mount to webhook container |
| webhook.extraVolumes | list | `[]` | Extra volumes to pass to webhook Pod |
| webhook.ha.enabled | bool | `false` | Enable high availability |
| webhook.ha.replicas | int | `3` | Number of replicas |
| webhook.hostNetwork | bool | `false` | Expose the webhook server in the host network |
| webhook.image.pullPolicy | string | `"IfNotPresent"` |  |
| webhook.image.repository | string | `"docker.mariadb.com/mariadb-enterprise-operator"` |  |
| webhook.image.tag | string | `""` | Image tag to use. By default the chart appVersion is used |
| webhook.imagePullSecrets | list | `[]` |  |
| webhook.nodeSelector | object | `{}` | Node selectors to add to webhook Pod |
| webhook.pdb.enabled | bool | `false` | Enable PodDisruptionBudget for the webhook. |
| webhook.pdb.maxUnavailable | int | `1` | Maximum number of unavailable Pods. You may also give a percentage, like `50%` |
| webhook.podAnnotations | object | `{}` | Annotations to add to webhook Pod |
| webhook.podSecurityContext | object | `{}` | Security context to add to webhook Pod |
| webhook.port | int | `9443` | Port to be used by the webhook server |
| webhook.priorityClassName | string | `""` | priorityClassName to add to webhook Pod |
| webhook.resources | object | `{}` | Resources to add to webhook container |
| webhook.revisionHistoryLimit | int | `10` | Specifies the amount of historic ReplicaSets k8s should keep (see https://kubernetes.io/docs/concepts/workloads/controllers/deployment/#clean-up-policy) |
| webhook.securityContext | object | `{}` | Security context to add to webhook container |
| webhook.serviceAccount.annotations | object | `{}` | Annotations to add to the service account |
| webhook.serviceAccount.automount | bool | `true` | Automounts the service account token in all containers of the Pod |
| webhook.serviceAccount.enabled | bool | `true` | Specifies whether a service account should be created |
| webhook.serviceAccount.extraLabels | object | `{}` | Extra Labels to add to the service account |
| webhook.serviceAccount.name | string | `""` | The name of the service account to use. If not set and enabled is true, a name is generated using the fullname template |
| webhook.serviceMonitor.additionalLabels | object | `{}` | Labels to be added to the webhook ServiceMonitor |
| webhook.serviceMonitor.enabled | bool | `true` | Enable webhook ServiceMonitor. Metrics must be enabled |
| webhook.serviceMonitor.interval | string | `"30s"` | Interval to scrape metrics |
| webhook.serviceMonitor.metricRelabelings | list | `[]` |  |
| webhook.serviceMonitor.relabelings | list | `[]` |  |
| webhook.serviceMonitor.scrapeTimeout | string | `"25s"` | Timeout if metrics can't be retrieved in given time interval |
| webhook.strategy | object | `{}` | Set deployment strategy |
| webhook.tolerations | list | `[]` | Tolerations to add to webhook Pod |
| webhook.topologySpreadConstraints | list | `[]` | topologySpreadConstraints to add to webhook Pod |

----------------------------------------------
Autogenerated from chart metadata using [helm-docs v1.14.2](https://github.com/norwoodj/helm-docs/releases/v1.14.2)
