#!/usr/bin/env bash
# Migrate the data of a password-based MariaDB to a new MariaDB with TLS client certificate authentication, with a
# short downtime, by replicating from the old one until the cutover.
#
#   ./03-migrate.sh sync      # load a consistent snapshot into the new MariaDB and start replicating from the old one
#   ./03-migrate.sh status    # replication state, and lag
#   ./03-migrate.sh cutover   # stop the writes in the old MariaDB, wait for the new one to catch up, stop replicating
#
# 'sync' does not stop the writes in the old MariaDB. The data of the databases is replicated, the accounts are not
# (the new MariaDB declares them as User and Grant resources, see 02-new-mariadb.yaml).
#
# Requirements: kubectl, and the old MariaDB with log_bin and a server_id different to the new one (see 01-old-mariadb.yaml).
set -euo pipefail

NAMESPACE="${NAMESPACE:-default}"
OLD="${OLD:-mdb-test}"
NEW="${NEW:-mariadb-repl}"
# User of the old MariaDB with REPLICATION SLAVE, and the Secret with its password.
REPL_USER="${REPL_USER:-repl-migration}"
REPL_SECRET="${REPL_SECRET:-repl-migration}"
REPL_SECRET_KEY="${REPL_SECRET_KEY:-password}"
# Secret with the CA that issued the server certificate of the old MariaDB, key 'ca.crt'.
OLD_CA_SECRET="${OLD_CA_SECRET:-${OLD}-ca-bundle}"
# Host of the old MariaDB as seen from the Pods of the new one. It must be in the server certificate.
OLD_HOST="${OLD_HOST:-${OLD}.${NAMESPACE}.svc.cluster.local}"
# Databases to migrate. By default all of them, except the system ones.
DATABASES="${DATABASES:-}"
CONNECTION="${CONNECTION:-migration}"
DUMP_FILE="${DUMP_FILE:-$(mktemp -t migration-dump.XXXXXX.sql)}"
CUTOVER_TIMEOUT="${CUTOVER_TIMEOUT:-120}"

k() { kubectl --namespace "$NAMESPACE" "$@"; }
log() { echo "==> $*" >&2; }
die() { echo "ERROR: $*" >&2; exit 1; }

primary_pod() { k get mariadb "$1" -o jsonpath='{.status.currentPrimary}'; }

OLD_POD="$(primary_pod "$OLD")"
NEW_POD="$(primary_pod "$NEW")"
[ -n "$OLD_POD" ] || die "MariaDB $OLD has no current primary, is it ready?"
[ -n "$NEW_POD" ] || die "MariaDB $NEW has no current primary, is it ready?"

# SQL in the old MariaDB: root with the password, read inside the Pod.
old_sql() { k exec -i "$OLD_POD" -c mariadb -- sh -c 'exec mariadb -uroot -p"$MARIADB_ROOT_PASSWORD" "$@"' _ "$@"; }
# SQL in the new MariaDB: root with the client certificate, there is no password.
new_sql() {
  k exec -i "$NEW_POD" -c mariadb -- mariadb -uroot -h127.0.0.1 \
    --ssl-cert=/etc/pki/client.crt --ssl-key=/etc/pki/client.key --ssl-ca=/etc/pki/ca.crt "$@"
}

databases() {
  if [ -n "$DATABASES" ]; then
    echo "$DATABASES"
    return
  fi
  old_sql -N -e "SELECT schema_name FROM information_schema.schemata \
    WHERE schema_name NOT IN ('mysql','information_schema','performance_schema','sys')" | tr '\n' ' '
}

slave_status() { new_sql -e "SHOW SLAVE '$CONNECTION' STATUS\\G"; }
status_field() { slave_status | awk -F': ' -v f="$1" '$1 ~ "^ *"f"$" {print $2}'; }

preflight() {
  log "Preflight checks"
  [ "$(old_sql -N -e 'SELECT @@log_bin')" = "1" ] || die "the old MariaDB needs log_bin enabled"
  local old_id new_id
  old_id="$(old_sql -N -e 'SELECT @@server_id')"
  new_id="$(new_sql -N -e 'SELECT @@server_id')"
  [ "$old_id" != "$new_id" ] || die "the old and the new MariaDB have the same server_id ($old_id)"
  [ "$(old_sql -N -e "SELECT COUNT(*) FROM mysql.user WHERE user='$REPL_USER'")" -ge 1 ] \
    || die "user $REPL_USER does not exist in the old MariaDB"
  if [ -n "$(new_sql -N -e "SHOW ALL SLAVES STATUS" 2>/dev/null | head -c1)" ]; then
    die "the new MariaDB already has replication connections, is a migration in progress? try: $0 status"
  fi
  local dbs existing
  dbs="$(databases)"
  for db in $dbs; do
    existing="$(new_sql -N -e "SELECT COUNT(*) FROM information_schema.schemata WHERE schema_name='$db'")"
    [ "$existing" = "0" ] || die "database $db already exists in the new MariaDB, it must be empty"
  done
}

sync() {
  preflight
  local dbs
  dbs="$(databases)"
  [ -n "$dbs" ] || die "nothing to migrate"
  log "Dumping databases from $OLD_POD: $dbs"
  # --single-transaction with --master-data takes a consistent snapshot together with its GTID position, holding a
  # global read lock only for a moment, so the writes in the old MariaDB are not stopped.
  # shellcheck disable=SC2086
  old_sql_dump() {
    k exec "$OLD_POD" -c mariadb -- sh -c 'exec mariadb-dump -uroot -p"$MARIADB_ROOT_PASSWORD" "$@"' _ "$@"
  }
  old_sql_dump --single-transaction --master-data=2 --gtid --routines --events --triggers --databases $dbs > "$DUMP_FILE"
  local gtid
  gtid="$(grep -m1 -oP "SET GLOBAL gtid_slave_pos='\K[^']+" "$DUMP_FILE")" || die "GTID position not found in $DUMP_FILE"
  log "Snapshot GTID position: $gtid"

  log "Loading the dump in $NEW_POD"
  # The load is not written to the binary log of the new MariaDB, it only has to contain replicated transactions.
  { echo "SET SESSION sql_log_bin=0;"; cat "$DUMP_FILE"; } | new_sql

  log "Copying the CA of the old MariaDB"
  k get secret "$OLD_CA_SECRET" -o jsonpath='{.data.ca\.crt}' | base64 -d \
    | k exec -i "$NEW_POD" -c mariadb -- sh -c 'cat > /tmp/old-ca.crt'

  log "Starting replication from $OLD_HOST"
  local password
  password="$(k get secret "$REPL_SECRET" -o jsonpath="{.data.$REPL_SECRET_KEY}" | base64 -d)"
  # Account statements (CREATE USER, GRANT...) of the old MariaDB must not reach the new one: they would overwrite
  # root, which requires the client certificate. The filter is only set for this replication connection.
  new_sql <<EOF
SET GLOBAL gtid_slave_pos='$gtid';
CHANGE MASTER '$CONNECTION' TO MASTER_HOST='$OLD_HOST', MASTER_PORT=3306, MASTER_USER='$REPL_USER',
  MASTER_PASSWORD='$password', MASTER_USE_GTID=slave_pos, MASTER_CONNECT_RETRY=10,
  MASTER_SSL=1, MASTER_SSL_CA='/tmp/old-ca.crt', MASTER_SSL_VERIFY_SERVER_CERT=1;
SET GLOBAL $CONNECTION.replicate_wild_ignore_table='mysql.%';
START SLAVE '$CONNECTION';
EOF
  rm -f "$DUMP_FILE"
  wait_running
  log "Replicating. Check it with: $0 status. When you are ready: $0 cutover"
}

wait_running() {
  local i
  for i in $(seq 1 30); do
    if [ "$(status_field Slave_IO_Running)" = "Yes" ] && [ "$(status_field Slave_SQL_Running)" = "Yes" ]; then
      return
    fi
    sleep 2
  done
  slave_status | grep -E "Last_(IO|SQL)_Error" >&2 || true
  die "replication is not running"
}

status() {
  slave_status | grep -E "Slave_IO_Running|Slave_SQL_Running:|Seconds_Behind_Master|Gtid_IO_Pos|Last_(IO|SQL)_Error|Replicate_Wild_Ignore_Table"
  echo "old gtid_binlog_pos: $(old_sql -N -e 'SELECT @@gtid_binlog_pos')"
  echo "new gtid_slave_pos:  $(new_sql -N -e 'SELECT @@gtid_slave_pos')"
}

cutover() {
  [ "$(status_field Slave_IO_Running)" = "Yes" ] || die "replication is not running, nothing to cut over. Check: $0 status"
  if [ "${YES:-}" != "true" ]; then
    echo "This makes $OLD read-only and promotes $NEW. Applications must be switched to $NEW afterwards."
    read -r -p "Continue? [y/N] " answer
    [ "$answer" = "y" ] || die "aborted"
  fi
  log "Making $OLD read-only"
  # read_only does not block SUPER users, applications must not connect with one.
  old_sql -e "SET GLOBAL read_only=1"
  local pos
  pos="$(old_sql -N -e 'SELECT @@gtid_binlog_pos')"
  log "Waiting for $NEW to reach $pos"
  local reached
  reached="$(new_sql -N -e "SELECT MASTER_GTID_WAIT('$pos', $CUTOVER_TIMEOUT)")"
  if [ "$reached" != "0" ]; then
    old_sql -e "SET GLOBAL read_only=0"
    die "$NEW did not catch up in ${CUTOVER_TIMEOUT}s, $OLD is writable again"
  fi
  new_sql -e "STOP SLAVE '$CONNECTION'; RESET SLAVE '$CONNECTION' ALL"
  verify
  log "Done. Switch your applications to $NEW. $OLD is read-only: delete it when you are sure."
}

# Compare the row count of every table.
verify() {
  log "Comparing row counts"
  local dbs failed=0 table old_count new_count
  dbs="$(databases)"
  for db in $dbs; do
    for table in $(old_sql -N -e "SELECT table_name FROM information_schema.tables WHERE table_schema='$db' AND table_type='BASE TABLE'"); do
      old_count="$(old_sql -N -e "SELECT COUNT(*) FROM \`$db\`.\`$table\`")"
      new_count="$(new_sql -N -e "SELECT COUNT(*) FROM \`$db\`.\`$table\`")"
      if [ "$old_count" != "$new_count" ]; then
        echo "MISMATCH $db.$table old=$old_count new=$new_count" >&2
        failed=1
      else
        echo "ok $db.$table $new_count"
      fi
    done
  done
  [ "$failed" = "0" ] || die "row counts differ"
}

case "${1:-}" in
  sync) sync ;;
  status) status ;;
  cutover) cutover ;;
  *) die "usage: $0 sync|status|cutover" ;;
esac
